//: Playground - noun: a place where people can play

import Cocoa

// Function
func saysHello() {
    print("Hello")
}


// Closure
var message = {
    print("Whats up!")
}

/* 
 
 Closures can also take parameters and return values
 
 
 { (params) -> returnType in
    ... Code block ...
 }
 
 
 
 For example
 
 { (a: String) -> String in
    ...does something with a...
    return someString
 }
 
 */


// ----------------------------

// Like functions closures take parameters 
// and return values
var multiplier = { (a: Int, b: Int) -> Int in
    return a * b
}

// Invoke a closure just like a function

multiplier(3, 4)

// -----------------------------






